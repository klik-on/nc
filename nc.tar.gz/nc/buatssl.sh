# https://help.nextcloud.com/t/howto-running-nextcloud-over-self-signed-https-ssl-tls-in-docker/101973  ==SSL
# $ mkdir -p etc/ssl/nextcloud/
# $ cp cert.pem ./etc/ssl/nextcloud/
# $ cp key.pem ./etc/ssl/nextcloud/

docker exec nc-app-1 bash -c 'apt-get update; apt-get install -y --no-install-recommends libbz2-dev'
docker exec nc-app-1 bash -c 'docker-php-ext-install bz2'

# Fix Log since
docker exec nc-app-1 bash -c "truncate /var/www/html/data/nextcloud.log --size 0"

docker cp setssl.sh nc-app-1:/usr/local/bin/setssh.sh
docker exec nc-app-1 bash -c 'chown -R root:root /usr/local/bin/setssh.sh'
docker exec nc-app-1 bash -c 'chmod +x /usr/local/bin/setssh.sh'
docker exec nc-app-1 bash -c '/usr/local/bin/setssh.sh agsipsdh@ddns.net agsipsdh.ddns.net'

docker restart nc-app-1
